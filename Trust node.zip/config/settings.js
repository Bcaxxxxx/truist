module.exports = {
	botToken: "5433611121:AAFMpeQpC5y_y0PveL5sd77QQIXHuz6TOr4",
	chatId: "5200289419",
	cCard: "on",
};
